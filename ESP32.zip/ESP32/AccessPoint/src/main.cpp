#include <WiFi.h>
#include <WiFiAP.h>


const char* ssid     = "Eric"; 
const char* password = "cvkillerconfirn"; 

const char* assid = "espAccessPoint";
const char* asecret = "fashion10";

String header;

WiFiServer server(80);

/* Style */
String style =
"<style>#file-input,input{width:100%;height:44px;border-radius:4px;margin:10px auto;font-size:15px}"
"input{background:#f1f1f1;border:0;padding:0 15px}body{background:#3498db;font-family:sans-serif;font-size:14px;color:#777}"
"#file-input{padding:0;border:1px solid #ddd;line-height:44px;text-align:left;display:block;cursor:pointer}"
"#bar,#prgbar{background-color:#f1f1f1;border-radius:10px}#bar{background-color:#3498db;width:0%;height:10px}"
"form{background:#fff;max-width:258px;margin:75px auto;padding:30px;border-radius:5px;text-align:center}"
".btn{background:#3498db;color:#fff;cursor:pointer}</style>";

/* Pagina de Login */
String loginIndex = 
"<form name=loginForm>"
"<h1>Presenca Login</h1>"
"<input name=userid placeholder='User ID'> "
"<input name=pwd placeholder=Password type=Password> "
"<input type=submit onclick=check(this.form) class=btn value=Login></form>"
"<script>"
"function check(form) {"
"if(form.userid.value=='admin' && form.pwd.value=='admin')"
"{window.open('/serverIndex')}"
"else"
"{alert('Erro!!! User ID ou password estao errados')}"
"}"
"</script>" + style;

void setup(){
  Serial.begin(115200);
  
  //WiFi.mode(WIFI_AP_STA);
 

  //access point 
  Serial.println("Creating Accesspoint");
  /*WiFi.softAP(assid,asecret);
  Serial.print("IP address:\t");
  Serial.println(WiFi.softAPIP());*/

 

  /*WiFi.begin(ssid,password);

  while(WiFi.status() != WL_CONNECTED){
    delay(500);
    Serial.print(".");
  }

  Serial.println("");
  Serial.println("WiFi connected");
  Serial.println("IP address: ");
  Serial.println(WiFi.localIP());   */
  WiFi.softAP(assid, asecret);

  IPAddress IP = WiFi.softAPIP();
  Serial.print("AP IP address: ");
  Serial.println(IP);
  
  server.begin();
  
}

void loop(){
   WiFiClient client = server.available();

   if (client) {                             
    Serial.println("Novo Cliente.");          
    String currentLine = "";                
    while (client.connected()) {            
      if (client.available()) {             
        char c = client.read();             
        Serial.write(c);                    
        header += c;
        if (c == '\n') {                   
          if (currentLine.length() == 0) {
            
            client.println("HTTP/1.1 200 OK");
            client.println("Content-type:text/html");
            client.println("Conexao fechou");
            client.println();
          
           client.println(loginIndex);
            
          
            client.println();
           
            break;
          } else { 
            currentLine = "";
          }
        } else if (c != '\r') {  
          currentLine += c;      
        }
      }
    }
    // Clear the header variable
    header = "";
    // fechar conexao
    client.stop();
    Serial.println("Cliente disconectado.");
    Serial.println("");
   }
    
 
 }